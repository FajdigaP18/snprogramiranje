﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Spomin
{
    public partial class ZacetniZaslon : Form
    {
        private int najboljsiRezulat = 0;
        private List<Igralec> igralci;
        private bool load = true;
        private string pot = @"Rezultati.json";
        public ZacetniZaslon()
        {
            InitializeComponent();
            if (load)
            {
                igralci = LoadJson();
                int i = igralci.Count;
                if (i > 0)
                {
                    najboljsiRezulat = igralci[0].Tocke;
                }
            }


        }


        /// <summary>
        /// S pritiskom na gumbzacni seodpre novo okno zaslon igra na katerem lahko zacnemo z iganjem.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gumbZacni_Click(object sender, EventArgs e)
        {
            
            ZaslonIgra zaslonIgra = new ZaslonIgra(4, 4, "Smejkoti", Properties.Resources.Snoopy4, uporabnik.Text, igralci);
            zaslonIgra.Show();
        }


        /// <summary>
        /// S pritiskom na gumb Nastavitve odpre okno zalsonNastavitve
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gumbNadtavitve_Click(object sender, EventArgs e)
        {
            ZaslonNastavitve zaslonNastavitve =  new ZaslonNastavitve(uporabnik.Text, igralci);
            zaslonNastavitve.Show();

        }
        public List<Igralec> LoadJson()
        {
            load = false;
            if (File.Exists(pot))
            {
                using (StreamReader r = new StreamReader(pot))
                {
                    string json = r.ReadToEnd();
                    List<Igralec> podatki = JsonSerializer.Deserialize<List<Igralec>>(json);
                    List<Igralec> podatki2 = podatki.OrderBy(x => x.Tocke).ToList();
                    najboljsiRezulat = podatki[0].Tocke;
                    return podatki2;
                }
            }
            else
            {
                najboljsiRezulat = 0;
                return new List<Igralec>();
            }
        }

        private void gumbNavodila_Click(object sender, EventArgs e)
        {
            ZaslonNavodila navodila = new ZaslonNavodila();
            navodila.Show();
        }
    }
}
