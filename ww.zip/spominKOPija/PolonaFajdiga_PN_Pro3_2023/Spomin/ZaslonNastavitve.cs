﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Spomin
{
    public partial class ZaslonNastavitve : Form
    {
        private string[] dimenzije = new string[] { "4", "4"};
        private string imeMape = "Smejkoti";
        private string imeHrtisca;
        private Image hrbtisce = Properties.Resources.Snoopy4;

        
        private List<string> imenaSlicic = new List<string>();

        private string povezava = "Data Source = podatki.db";

        private string potSlike = "";
        private string uporabnik;

        private List<Igralec> igralci;
        public ZaslonNastavitve(string ime, List<Igralec> seznam)
        {
            InitializeComponent();
            uporabnik = ime;
            igralci = seznam;
        }

        /// <summary>
        /// Izberemo dimenzije igralne površine.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dimenzijeIgralnePovrsine_SelectedIndexChanged(object sender, EventArgs e)
        {   
            string selectVal = comboBox1.Text;
            string vrednost = comboBox1.Text;
            dimenzije = vrednost.Split(':');
            shrani.Enabled = false;
        }

        /// <summary>
        /// Z gumbom začni odpremo novo okno ZaslonIgra
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void zacni_Click(object sender, EventArgs e)
        {
            ZaslonIgra zaslonIgra = new ZaslonIgra(int.Parse(dimenzije[0]), int.Parse(dimenzije[1]), imeMape, hrbtisce, uporabnik, igralci);
            zaslonIgra.Show();
            Close();
        }

        /// <summary>
        /// Izberemo temo sličic.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void temaSlicic_SelectedIndexChanged(object sender, EventArgs e)
        {
            imeMape = temaSlicic.Text;
            shrani.Enabled = false;
        }

        /// <summary>
        /// Z gumbom Zapri zapremo okno ZaslonNastavitev.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void zapri_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Z gumbom Naloži naložimo sliko tipa .jpg ali png  in jo prikažemo v prostorcku za sliko.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nalozi_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "jpg|*.jpg|png|*.png";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                potSlike = dialog.FileName;
                naloziSliko.Image = new Bitmap(potSlike);
                naloziSliko.Visible = true;
                naloziSliko.SizeMode = PictureBoxSizeMode.StretchImage;
                naloziSliko.Size = new Size(200,200);
            }
            shrani.Enabled = true;
        }

        /// <summary>
        /// S klikom na gumb Shrani shranimo sliko, ki smo jo naložili.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void shrani_Click(object sender, EventArgs e)
        {
            try
            {
                string imeSlike = Path.GetFileName(potSlike);
                imenaSlicic.Add(potSlike);
                File.Copy(potSlike, Path.Combine(@"Hrbtna stran\", imeSlike), true);
                MessageBox.Show("Slika je  uspesno shranjena!!");
                shrani.Enabled = false;
                if (!izberiHrbtsce.Items.Contains(imeSlike))
                {
                    izberiHrbtsce.Items.Add(imeSlike);
                }

            }
            catch
            {
                MessageBox.Show("Sliko morate prvo naložiti");
            }

        }

        /// <summary>
        /// V seznamu izberemo naslov hrbtne strani sličice in jo prikažemo na zaslonu.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void izberiHrbtsce_SelectedIndexChanged(object sender, EventArgs e)
        {
            imeHrtisca = izberiHrbtsce.Text;
            hrbtisce = Image.FromFile($"Hrbtna stran\\{imeHrtisca}");
            naloziSliko.Image = hrbtisce;
            shrani.Enabled = false;

        }

        /// <summary>
        /// Ko poženemo zaslon zaslonNastavitve moramo prvo pogledati katere hrbtne stranisličic imamo na razpolago.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ZaslonNastavitve_Load(object sender, EventArgs e)
        {
            string[] imena = Directory.GetFiles(@"Hrbtna stran");
            foreach (string ime in imena)
            {
                imenaSlicic.Add(ime); // to lahko zbrises!!
                // v seznam hrbtnih strani kartic shranimo ime sličice
                izberiHrbtsce.Items.Add(Path.GetFileName(ime));
            }
            shrani.Enabled = false;
        }
    }
}
